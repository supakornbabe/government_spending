# Spending of Ministry of Interior that use in Bangkok.
##### All Excel(xlsx) files are generate by Google spreadsheet. Some function may not work properly so please open it with Google spreadsheet. 
##### [Github](https://github.com/supakornbabe/government_spending)
### Supakorn Wongsawang 5910500147